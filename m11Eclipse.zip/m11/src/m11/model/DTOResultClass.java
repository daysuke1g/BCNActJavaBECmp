/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package m11.model;

/**
 *
 * @author JoseLuis.Canivano
 */
public class DTOResultClass 
{
  public boolean booleanValue1;
  public String  stringValue1;
  public float   floatValue1;

    
}
